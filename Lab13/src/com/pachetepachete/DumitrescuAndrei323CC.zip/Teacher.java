package com.pachetepachete;

public class Teacher extends User {
    public Teacher(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
