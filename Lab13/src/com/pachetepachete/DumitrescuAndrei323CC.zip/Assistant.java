package com.pachetepachete;

public class Assistant extends User {
    public Assistant(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
