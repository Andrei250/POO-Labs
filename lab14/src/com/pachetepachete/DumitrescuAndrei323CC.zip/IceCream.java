package com.pachetepachete;

public interface IceCream {
    String getDescription();
    double getCost();
    String getIng();
}
