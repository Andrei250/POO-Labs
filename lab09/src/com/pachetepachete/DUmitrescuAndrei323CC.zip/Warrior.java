package com.pachetepachete;

public class Warrior extends Hero {

    @Override
    void print(Hero h) {
        System.out.println("Warrior");
    }
}
