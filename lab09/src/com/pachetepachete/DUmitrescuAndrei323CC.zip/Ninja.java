package com.pachetepachete;

public class Ninja extends Hero {

    @Override
    void print(Hero h) {
        System.out.println("Ninja");
    }
}
