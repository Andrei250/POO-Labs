package com.pachetepachete;

public abstract class Hero {
    abstract void print(Hero h);
}
