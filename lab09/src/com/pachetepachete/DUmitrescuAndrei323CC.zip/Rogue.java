package com.pachetepachete;

public class Rogue extends Hero {

    @Override
    void print(Hero h) {
        System.out.println("Rogue");
    }
}
