package com.pachetepachete;

public interface Stragety {
    double calcul(int aniVechime, float salariu);
}
