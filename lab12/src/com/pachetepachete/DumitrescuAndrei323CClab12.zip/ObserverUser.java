package com.pachetepachete;

public interface ObserverUser {
    void notify(String notification);
}
